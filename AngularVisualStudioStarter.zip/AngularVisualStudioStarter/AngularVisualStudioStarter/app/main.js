﻿"use strict";

angular.module('MainApp', [])

.controller("MainController", function ($scope) {

    //main();

    //function main() {
    //    var vm = this;
    //    vm.food = 'pizza';

    //    return this.food;
    //}
    
    //Define the products
    init();

    //Function definition
    function init() {

        $scope.prodList = [
                            { "id": "1", "name": "window", "price": "100" },
                            { "id": "2", "name": "door", "price": "356" },
                            { "id": "3", "name": "table", "price": "505" }
        ];

        $scope.orders = {};
        $scope.orders.prods = {};
        $scope.orders.prods.prod = {};
        $scope.sum = 0;
    }

    //Logic for checkboxes summary
    $scope.addMe = function (checked, val) {
        val = 1 * val
        if (!checked) {
            $scope.sum = $scope.sum - (val);
        } else
            $scope.sum = $scope.sum + (0 + val);
    }

})

//(function () {
//    'use strict';

//    angular
//        .module('app')
//        .controller('Main', main);

//    function main() {
//        var vm = this;
//        vm.food = 'pizza';
//    }

//})();


////angular.module("Main",[])